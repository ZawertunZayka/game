Each row has 2 crops, first and sixth columns are
portraits.

16x16 spritesheet, no padding, no margin

Crop list (from left to right, top to bottom)
- Turnip
- Rose
- Cucumber
- Tulip
- Tomato
- Melon
- Eggplant
- Lemon
- Pineapple
- Rice
- Wheat
- Grapes
- Straberry
- Cassava
- Potato
- Coffee
- Orange
- Avocado
- Corn
- Sunflower

License (CC0)
http://creativecommons.org/publicdomain/zero/1.0/

Can be used for personal and commercial projects.
Credit to my profile page (https://opengameart.org/users/josehzz) would be appreciated, but this is not requiered.